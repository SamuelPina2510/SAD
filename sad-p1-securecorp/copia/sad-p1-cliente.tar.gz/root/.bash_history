echo "TLS_CACERT /pki/ca/ca.crt" >> /etc/ldap/ldap.conf
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
nano /etc/ldap/ldap.conf
ls -l /pki/ca/ca.crt
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ls -l /etc/ldap/tls/
exit
nano /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
exit
service slapd restart
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
kinit samuelpina2510
kvno host/web.securecorp.local
kinit lromero
kinit mtorres
exit
nano etc/ldap/ldap.conf
exit
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=samuelpina2510,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=samuelpina2510,ou=people,dc=securecorp,dc=local" -W
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
clear
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=people,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
cd /ldif
nano 02-tu-turno.ldif 
exit
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W \ -s 'Hugo2026' "uid=hdiez,ou=people,dc=securecorp,dc=local"
cd /ldif
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W \ -s 'Hugo2026' "uid=hdiez,ou=people,dc=securecorp,dc=local"
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
exit
cd /ldif
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W \ -s 'Hugo2026' "uid=hdiez,ou=people,dc=securecorp,dc=local"
cd /ldif
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
nano 02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W \ -s 'Hugo2026' "uid=hdiez,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W \ -s 'Hugo2026' "uid=hdiez,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Hugo2026' "uid=hdiez,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=hdiez,ou=people,dc=securecorp,dc=local" -w 'Hugo2026'
exit
