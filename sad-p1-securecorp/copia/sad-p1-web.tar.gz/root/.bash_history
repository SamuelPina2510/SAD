kinit samuelpina2510
exit
kinit samuelpina2510@SECURECORP.LOCAL
exit
