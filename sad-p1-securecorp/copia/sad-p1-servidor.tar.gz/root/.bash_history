service krb5-kdc start
kdb5_util create -s -r SECURECORP.LOCAL
service krb5-kdc start
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc samuelpina2510"
kadmin.local -q "addprinc mtorres"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "modprinc +DISALLOW_ALL_TIX mtorres"
exit
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/01-ejemplo.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif
# Contraseña para ti:
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'TuContraseña' "uid=samuelpina2510,ou=people,dc=securecorp,dc=local"
# Contraseña para Marta:
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
exit
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/ldap
nano /etc/ldap/ldap.crt
nano /etc/default/slapd
exit
nano /etc/ldap/tls
exit
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
cat /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
exit
service slapd restart
 ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
nano /etc/default/slapd
exit
service slapd restart
slapd -tt
service slapd restart
grep SLAPD_SERVICES /etc/default/slapd
pkill -9 slapd
slapd -d 1 -F /etc/ldap/slapd.d
service slapd restart
exit
nano /etc/default/slapd 
nano /etc/default/slapd 
exit
kadmin.local -q "addprinc lromero"
exit
kadmin.local -q "listprinc"
kadmin.local -q "listprincs"
exit
cd /ldif/
nano 02-tu-turno.ldif
exit
nano etc/ldap/ldap.conf
exit
exit
exit
